#include "Camera.h"


Camera::Camera(void)
{		
	vert_angle = 0.0;
	horiz_angle = 0.0;
	fov = 80.0f;
}

Camera::~Camera(void)
{
}
