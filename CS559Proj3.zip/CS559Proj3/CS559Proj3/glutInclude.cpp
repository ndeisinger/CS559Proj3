#include "glutInclude.h"
bool useShadows = false;
RENDER_TARGET render_target = RENDER_FULL;
RENDER_SHADER render_shader = TEX_SHADER;
